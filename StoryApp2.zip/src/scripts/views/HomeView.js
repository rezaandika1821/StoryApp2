const HomeView = {
  getStoryListContainer() {
    return document.querySelector('#storyListContainer');
  },

  getMapElement() {
    return document.querySelector('#map');
  },

  runViewTransition(callback) {
    if (window.document.startViewTransition) {
      window.document.startViewTransition(callback);
    } else {
      callback();
    }
  },
  getTemplate() {
    return `
      <section class="container" aria-label="Halaman Utama">
        <h1>Daftar Cerita</h1>
        <div id="storyListContainer" class="story-list" aria-live="polite">
          <p id="loadingMessage">Memuat data cerita...</p>
        </div>
        <div id="map" style="height: 400px; width: 100%; margin-top: 2rem;" aria-label="Peta lokasi cerita"></div>
      </section>
    `;
  },

  clearLoading(container) {
    container.innerHTML = '';
  },

  renderStories(container, stories) {
    stories.forEach((story) => {
      const card = document.createElement('article');
      card.classList.add('story-card');
      card.setAttribute('tabindex', '0');
      card.setAttribute('role', 'article');

      card.innerHTML = `
        <img src="${story.photoUrl}" alt="Foto oleh ${story.name}" loading="lazy" />
        <h3>${story.name}</h3>
        <p>${story.description}</p>
        <small>${new Date(story.createdAt).toLocaleString()}</small>
      `;

      card.addEventListener('click', () => {
        if (document.startViewTransition) {
          document.startViewTransition(() => {
            console.log('Transisi halaman cerita (belum implementasi detail)');
          });
        }
      });

      container.appendChild(card);
    });
  },

  addStoryMarkers(map, stories) {
    stories.forEach((story) => {
      if (story.lat && story.lon) {
        const marker = L.marker([story.lat, story.lon]).addTo(map);
        marker.bindPopup(`
          <strong>${story.name}</strong><br>
          ${story.description}
        `);
      }
    });
  },

  showError(container, message) {
    container.innerHTML = `<p class="error" role="alert">Gagal memuat data. ${message}</p>`;
  }
};

export default HomeView;
