// File: src/scripts/presenters/HomePresenter.js
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';
import { fixLeafletIcons } from '../utils/fixLeafletIcons';
import API from '../data/api.js';
import HomeView from '../views/HomeView.js';

const HomePresenter = {
  async init() {
    // Perbaiki path ikon Leaflet sebelum inisialisasi peta
    fixLeafletIcons();

    const container = HomeView.getStoryListContainer();
    const mapElement = HomeView.getMapElement();
    let map = null;

    try {
      const stories = await API.getAllStories();

      const renderContent = () => {
        HomeView.clearLoading(container);
        HomeView.renderStories(container, stories);
      };

      // Gunakan View Transition API jika tersedia, lewat View
      HomeView.runViewTransition(renderContent);

      // Inisialisasi peta
      map = L.map(mapElement).setView([-2.5489, 118.0149], 4);

      // Tambahkan tile layer OSM & OpenTopoMap
      const baseOSM = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors',
      });

      const baseTopo = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenTopoMap contributors',
      });

      baseOSM.addTo(map); // Tambahkan layer default

      // Kontrol layer untuk switching antar-peta
      L.control.layers(
        { 'OpenStreetMap': baseOSM, 'OpenTopoMap': baseTopo },
        {},
        { collapsed: false }
      ).addTo(map);

      // Tambahkan marker dari cerita
      HomeView.addStoryMarkers(map, stories);
    } catch (error) {
      HomeView.showError(container, error.message);
      if (map) map.remove();
    }
  },
};

export default HomePresenter;
